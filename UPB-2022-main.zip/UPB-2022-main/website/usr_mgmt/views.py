from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.shortcuts import render, redirect
from .forms import loginForm, registerForm
from django.contrib.auth import login,logout, authenticate
from django.views.decorators.csrf import csrf_exempt
#from django.contrib.auth.models import User
from .models import customUser as User
from django.contrib.auth.models import ( AbstractUser, BaseUserManager)
import json
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

RECEIVED_FILES = BASE_DIR / 'received_files'

@csrf_exempt
def login_usr(request):
    if request.method == "GET":
        return render(request, "login.html", {})

    elif request.method == "POST":
        form = loginForm(request.POST)
        if form.is_valid():
            user = authenticate(username=form.cleaned_data['login'], 
                        password=form.cleaned_data['password'])
            if user is not None:
                login(request, user)
            return render(request, "login.html", {})
        else:
            return render(request, "login.html", {})

@csrf_exempt
def register_usr(request):
    if request.method == "GET":
        return render(request, "register.html", {})

    elif request.method == "POST":
        form = registerForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                validate_password(form.cleaned_data['password'])
            except ValidationError as err:
                return render(request, "register.html", {'pwd': json.dumps(err.messages), 'login' : form.cleaned_data['login']})
            user = User.objects.create_user(username=form.cleaned_data['login'], 
                                            password=form.cleaned_data['password'],
                                            pub_key=form.cleaned_data['key'].read())
            path = os.path.join(RECEIVED_FILES, form.cleaned_data['login'])
            try: 
                if not os.path.exists(RECEIVED_FILES):
                    os.makedirs(RECEIVED_FILES) 
            except OSError as error: 
                print(error)
            try: 
                os.mkdir(path) 
            except OSError as error: 
                print(error)
            login(request, user)
            return redirect('/')
            
            
        else:
            return render(request, "register.html", {})

def logout_usr(request):
    logout(request)
    return redirect('/')