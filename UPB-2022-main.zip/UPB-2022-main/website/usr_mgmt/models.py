from django.db import models
from django.contrib.auth.models import ( AbstractUser, BaseUserManager)
from .hash import Hash


class customUserManager(BaseUserManager):
    def create_user(self, username,  password, **extra_fields):
        if not username:
            raise ValueError("The given username must be set")
        
        user = self.model(username=username, **extra_fields)
        user.password, user.salt = Hash.hash_password(password)
        user.save(using=self._db)
        return user


class customUser(AbstractUser):
    username = models.CharField(unique=True, max_length=100)
    pub_key = models.BinaryField()
    salt = models.BinaryField(null=True)
    password = models.BinaryField()
    objects = customUserManager()


