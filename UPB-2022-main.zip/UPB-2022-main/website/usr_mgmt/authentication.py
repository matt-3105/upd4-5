from django.contrib.auth.backends import BaseBackend
from .hash import Hash
from .models import customUser

class customAuthBackend(BaseBackend):
    def authenticate(self, request=None, username=None, password=None):
        try:
            user = customUser.objects.get(username=username)
            if Hash.verify(password, user.password, user.salt):
                return user
            return None
        except customUser.DoesNotExist:
            return None

    def get_user(self, user_id):
        try:
            return customUser.objects.get(pk=user_id)
        except customUser.DoesNotExist:
            return None
