from django.urls import URLPattern, path
from . import views

urlpatterns = [
    path('login/', views.login_usr, name='login_usr'),
    path('register/', views.register_usr, name='register_usr'),
    path('logout/', views.logout_usr, name='logout_usr')
]