from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidKey, AlreadyFinalized   
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os



class Hash:

    ITER_COUNT = 10000

    def hash_password(password):
        salt = os.urandom(16)
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(),
                        length=32, salt=salt, iterations=Hash.ITER_COUNT)
        hash = kdf.derive(bytes(password, 'utf-8'))
        return(hash, salt)

    def verify(password, hash, salt):
        
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(),
                        length=32, salt=salt, iterations=Hash.ITER_COUNT)
        try:
            kdf.verify(bytes(password, 'utf-8'), hash)
            return True
        except Exception: 
            return False
