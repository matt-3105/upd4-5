from django.core.exceptions import ValidationError
from django.utils.translation import gettext as _

class LetterValidator:
    def __init__(self, min_length=8):
        self.min_length = min_length

    def validate(self, password, user=None):
        upperpassword = password.upper()
        lowerpassword = password.lower()
        if upperpassword == password or lowerpassword == password:
            raise ValidationError(
                _("This password must contain uppercase and lowercase letters."),
                code='password_without_uppercase_or_lowercase_letters',
            )

    def get_help_text(self):
        return _(
            "Your password must contain uppercase and lowercase letters."
        )


class NumberValidator:
    def __init__(self, min_length=8):
        self.min_length = min_length

    def validate(self, password, user=None):
        if not (any(char.isdigit() for char in password)):
            raise ValidationError(
                _("This password must contain atleast 1 number."),
                code='password_without_letter',
            )

    def get_help_text(self):
        return _(
            "Your password must contain atleast 1 number."
        )