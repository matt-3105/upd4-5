from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
import os

class Crypt:

        PUBLIC_EXPONENT = 65537
        ASYM_KEY_SIZE = 512 #bytes 
        SYM_KEY_SIZE = 32 #bytes

        def encr(key, message ):
                
                public_key = serialization.load_pem_public_key(key)
                sym_key = os.urandom(Crypt.SYM_KEY_SIZE)
                iv = os.urandom(16)
                encryptor = Cipher(algorithm=algorithms.AES(sym_key), mode=modes.GCM(iv)).encryptor()
                sym_key_enc = public_key.encrypt(sym_key,
                                        padding.OAEP(
                                        mgf=padding.MGF1(algorithm=hashes.SHA256()),
                                        algorithm=hashes.SHA256(),
                                        label=None))

                encr_message = sym_key_enc
                encr_message += iv
                auth_data = iv + sym_key_enc
                encryptor.authenticate_additional_data(auth_data)
                encr_message += encryptor.update(message) + encryptor.finalize()
                encr_message += encryptor.tag

                return  encr_message
                
                

        def decr(key, message):

                private_key = serialization.load_pem_private_key(key, password=None)
                
                sym_key_enc = message[:Crypt.ASYM_KEY_SIZE]
                message = message[Crypt.ASYM_KEY_SIZE:]
                iv = message[:16]
                tag = message[-16:]
                message = message[16:-16]
                sym_key = private_key.decrypt(sym_key_enc, 
                                        padding.OAEP(
                                        mgf=padding.MGF1(algorithm=hashes.SHA256()),
                                        algorithm=hashes.SHA256(),
                                        label=None))

                decryptor = Cipher(algorithm=algorithms.AES(sym_key), mode=modes.GCM(iv, tag)).decryptor()
                auth_data = iv + sym_key_enc
                decryptor.authenticate_additional_data(auth_data)
                decr_message = decryptor.update(message) + decryptor.finalize()

                return decr_message