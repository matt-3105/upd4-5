from django import forms

class fileSubmitForm(forms.Form):
    file = forms.FileField(label='File', max_length=100)
    key = forms.FileField(label='Key', max_length=100)

class fileSendForm(forms.Form):
    user = forms.CharField(label='user', max_length=100)
    file = forms.FileField(label='file', max_length=100)
    
class downloadForm(forms.Form):
    file_name = forms.CharField(label='file_name', max_length=100)