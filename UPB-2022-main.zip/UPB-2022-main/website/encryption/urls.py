from django.urls import URLPattern, path
from . import views

urlpatterns = [
    path('enc/', views.encryption, name='encryption'),
    path('dec/', views.decryption, name='decryption'),
    path('send/', views.send, name='send'),
    path('receive/', views.receive, name='receive'),
    path('', views.index, name='index'),
]