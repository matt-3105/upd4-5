from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from django.http import HttpResponse

from .forms import fileSubmitForm
from .forms import fileSendForm,downloadForm
import pathlib
import os

from website import settings

from django.views.static import serve
from .crypt import Crypt

from usr_mgmt.models import customUser

UPLOADS_DIR = settings.BASE_DIR/'uploads'

RECEIVED_FILES = settings.BASE_DIR / 'received_files'

@csrf_exempt
def encryption(request):
    if request.method == "GET":
        return render(request, "form_enc.html", {})
    
    elif request.method == "POST":
        form = fileSubmitForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.cleaned_data['file']
            key = form.cleaned_data['key']
            
            try: 
                encr_message = Crypt.encr(key.read() , file.read())
            except:
                return render(request, "fail.html", {})

            with open(UPLOADS_DIR / pathlib.Path('enc_'+file.name), "wb+") as f:
                f.write(encr_message)

            with open(UPLOADS_DIR / pathlib.Path('enc_'+file.name), "rb") as f:
                response  = HttpResponse(f.read(), content_type="application/vnd.ms-excel")
                response['Content-Disposition'] = 'inline; filename=' + 'enc_'+file.name
                return response
        else:
            print("not valid")
            return render(request, "form_enc.html", {})



@csrf_exempt
def decryption(request):
    if request.method == "GET":
        return render(request, "form_dec.html", {})#'form': form
    
    elif request.method == "POST":
        form = fileSubmitForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.cleaned_data['file']
            key = form.cleaned_data['key']
            
            try: 
                decr_message = Crypt.decr(key.read() , file.read())
            except:
                return render(request, "fail.html", {})

            response  = HttpResponse(decr_message, content_type="application/vnd.ms-excel")
            response['Content-Disposition'] = 'inline; filename=' + 'dec_'+file.name
            return response
        else:
            return render(request, "form_dec.html", {})



def index(request):
    if request.method == "GET":
        return render(request, "index.html", {})
    
    
@csrf_exempt
def send(request):
    users = customUser.objects.all()
    if request.method == "GET":
        return render(request, "send.html",{'users':users})
    
    elif request.method == "POST":
        form = fileSendForm(request.POST, request.FILES)        
        if form.is_valid():
            file = form.cleaned_data['file']
            user_selected = form.cleaned_data['user']
            for user in users:
                if user.username == user_selected:
                    key = user.pub_key
                    path = RECEIVED_FILES / user_selected            
            try: 
                encr_message = Crypt.encr(key, file.read())
            except Exception as e:
                print(str(e))
                return render(request, "send.html", {})

            with open(path / pathlib.Path('enc_'+file.name), "wb+") as f:
                f.write(encr_message)
            return render(request,"send.html",{})
        else:
            return render(request, "send.html", {})        
        
  
  
  
@csrf_exempt    
def receive(request):
    users = customUser.objects.all()
    current_user = request.user        
    username = current_user.username        
    path = RECEIVED_FILES / username
    if request.method == "GET":
    
        dir_list = os.listdir(path)     
        
        return render(request, "receive.html", {'list': dir_list, 'path': path})
    elif request.method == "POST":
        form = downloadForm(request.POST)
        
        if form.is_valid():
            file_name = form.cleaned_data['file_name']
            
            for user in users:
                if user.username == username:
                    key = user.pub_key
            file_path = path  / file_name
            try:
                with open(file_path, 'rb') as file: 
                    decr_message = Crypt.decr(key , file.read())
            except Exception as e:
                value = str(e)
                return render(request, "receive.html", {'value': value})

            with open(file_path / pathlib.Path(file_name), "wb+") as ff:
                ff.write(decr_message)
                response  = HttpResponse(decr_message, content_type="application/vnd.ms-excel")
                response['Content-Disposition'] = 'inline; filename=' 'dec_'+ file_name
                
                value = 'dobre vyborne'
                return render(request, "receive.html", {'value': value})
        else:
            value = 'nepreslo nic'
            return render(request, 'receive.html',{'value': value})        