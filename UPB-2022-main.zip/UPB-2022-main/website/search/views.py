from django.shortcuts import render

def search(request):
    if request.method == "GET":
        #form = fileSubmitForm()
        return render(request, "search.html", {})
