## Build and start image 
sudo docker-compose up --build

## shutdown
docker-compose down

## admin
login: admin
password: password123
